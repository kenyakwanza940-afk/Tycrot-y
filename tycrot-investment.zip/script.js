function start() {
    alert("Welcome to Tycrot Investment! Registration coming soon.");
}
