# Tycrot Investment

A simple investment website built using HTML, CSS, and JavaScript.

## Features
- Investment plans display
- Clean UI
- Mobile responsive
- Easy to upgrade

## Future Improvements
- User login system
- M-Pesa integration
- Dashboard
- Real investment tracking

## Author
Tycrot Investment
